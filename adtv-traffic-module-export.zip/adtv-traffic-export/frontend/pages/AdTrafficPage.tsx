import React from 'react';
import { AdTrafficDashboard } from '../components/AdTraffic';

const AdTrafficPage: React.FC = () => {
  return <AdTrafficDashboard />;
};

export default AdTrafficPage; 